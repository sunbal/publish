# Casper System Monitor

Ubuntu(GNOME) 상단바에 AI 서비스의 **남은 사용량**을 표시하는 트레이 인디케이터.

```
Claude  5h: 62% left │ 7d: 80% left     ← 5시간 세션 / 7일 한도 남은 % (한도 설정 시)
Claude  5h: 168k used │ 7d: 478k used    ← 한도 미설정 시 사용한 토큰 수
```

클릭하면 항목별 막대 그래프(남은 %에 따라 초록/주황/빨강), 사용 토큰, 리셋까지 남은 시간이 나옵니다.

## 지원 현황

| 서비스 | 상태 | 데이터 출처 |
|---|---|---|
| Claude Code | 지원 | 로컬 로그 `~/.claude/projects/**/*.jsonl` (네트워크·토큰 사용 없음) |
| Gemini | 미구현 | `providers/gemini.py` 참고 |

> **"남은 %"는 추정치입니다.** Anthropic은 구독의 실제 남은 한도를 로컬에 제공하지 않고,
> 서버 조회용 엔드포인트는 비공식이며 약관상 위험이 있어 사용하지 않습니다.
> 대신 로그의 토큰(입력+출력+캐시 생성)을 합산하고, **직접 설정한 한도**와 비교해 %를 계산합니다.
> 한도를 설정하지 않으면 사용한 토큰 수만 표시합니다.
>
> - **5h**: 첫 메시지 시각(정시 기준)부터 5시간짜리 세션 블록. 블록이 끝나면 0으로 리셋.
> - **7d**: 최근 7일 롤링 합계. 실제 구독의 주간 리셋 시각과는 다를 수 있습니다.
> - 이 PC의 Claude Code 로그만 집계합니다. 다른 기기나 claude.ai 웹 사용량은 포함되지 않습니다.

## 설치

요구사항: Ubuntu GNOME, Python 3, Claude Code 사용 기록.

배포 파일 `system_monitor.tgz`를 받아 원하는 위치에 풀고 `install.sh`를 실행합니다.
자동 시작 항목이 압축을 푼 폴더의 경로를 가리키므로, 설치 후에는 폴더를 옮기지 마세요 (옮겼다면 `./install.sh`를 다시 실행).

```bash
curl -LO https://github.com/sunbal/publish/raw/main/system_monitor.tgz
mkdir -p ~/apps && tar xzf system_monitor.tgz -C ~/apps
cd ~/apps/system_monitor
./install.sh
```

`install.sh`는 다음을 합니다.
- `gir1.2-ayatanaappindicator3-0.1`, `gnome-shell-extension-appindicator` 설치 (sudo 필요)
- 로그인 시 자동 실행되도록 `~/.config/autostart/casper-system-monitor.desktop` 등록

삭제하려면:

```bash
./install.sh clean
```

실행 중인 모니터를 종료하고 자동 시작 항목을 삭제합니다. 설정 폴더와 apt 패키지는 각각 확인 후 삭제합니다.
소스 폴더는 지우지 않습니다.

## 실행

설치 후 로그아웃했다가 다시 로그인하면 자동으로 실행됩니다. 바로 실행하려면 압축을 푼 폴더에서:

```bash
python3 casper_monitor.py &
```

종료는 트레이 메뉴의 `Quit`을 누릅니다.

GNOME에서 트레이 아이콘이 보이지 않으면 확장 기능 `AppIndicator and KStatusNotifierItem Support`가 켜져 있는지 확인하세요.

## 동작 확인 (GUI 없이)

```bash
python3 casper_monitor.py --once   # 요약 출력
python3 casper_monitor.py --dump   # 계산된 값을 JSON으로 출력
```

## 설정

`~/.config/casper_system_monitor/config.json` (선택)

```json
{
  "interval_seconds": 120,
  "limit_5h": 2000000,
  "limit_7d": 20000000,
  "count_cache_read": false
}
```

- `limit_5h`, `limit_7d`: 5시간 / 7일 토큰 한도. 직접 적거나, 아래 `--calibrate`로 자동 계산할 수 있습니다.
- `count_cache_read`: 캐시 읽기 토큰까지 합산할지 여부 (기본 false).

### 한도 자동 맞추기 (calibrate)

Claude Code에서 `/usage`로 현재 사용률(%)을 확인한 뒤, 같은 시점에 실행합니다.

```bash
python3 casper_monitor.py --calibrate 5h 40   # /usage가 5시간 40%라면
python3 casper_monitor.py --calibrate 7d 25   # 주간 25%라면
```

현재 로그의 사용 토큰이 그 %가 되도록 한도를 계산해 설정 파일에 저장합니다.
실행 중인 모니터는 다음 갱신 때 반영됩니다. 사용률이 어느 정도 올라간 뒤에 맞출수록 정확합니다.

## 구조

```
casper_monitor.py            실행 진입점
casper_monitor/app.py        설정, 요약 문자열, CLI 모드
casper_monitor/tray.py       트레이 UI, 갱신 루프 (GTK/AppIndicator)
casper_monitor/providers/    서비스별 데이터 수집 (claude.py, gemini.py)
install.sh                   의존성 설치 + 자동 시작 등록
```

새 서비스는 `providers/`에 `fetch()`를 구현해 추가합니다. 반환 형식은 `providers/claude.py` 참고.
