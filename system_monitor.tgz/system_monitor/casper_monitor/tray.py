import gi
import threading

from .app import bar, load_config, summary
from .providers import claude

gi.require_version("Gtk", "3.0")
from gi.repository import GLib, Gtk  # noqa: E402

try:
    gi.require_version("AyatanaAppIndicator3", "0.1")
    from gi.repository import AyatanaAppIndicator3 as AppIndicator
except (ValueError, ImportError):
    gi.require_version("AppIndicator3", "0.1")
    from gi.repository import AppIndicator3 as AppIndicator


class Monitor:
    def __init__(self):
        self.ind = AppIndicator.Indicator.new(
            "casper-system-monitor", "utilities-system-monitor",
            AppIndicator.IndicatorCategory.SYSTEM_SERVICES)
        self.ind.set_status(AppIndicator.IndicatorStatus.ACTIVE)
        self.ind.set_label("Claude …", "Claude\u20035h: 100% left\u2003\u2502\u20037d: 100% left")
        self.set_menu(["<i>Loading…</i>"])
        self.refresh()
        GLib.timeout_add_seconds(load_config()["interval_seconds"], self.refresh)

    def set_menu(self, lines):
        """`lines` are Pango markup strings."""
        menu = Gtk.Menu()
        for markup in lines:
            if markup == "-":
                menu.append(Gtk.SeparatorMenuItem())
                continue
            item = Gtk.MenuItem()
            label = Gtk.Label()
            label.set_markup(markup)
            label.set_xalign(0)
            item.add(label)
            menu.append(item)
        menu.append(Gtk.SeparatorMenuItem())
        for text, cb in (("Refresh now", lambda *_: self.refresh()),
                         ("Quit", lambda *_: Gtk.main_quit())):
            item = Gtk.MenuItem(label=text)
            item.connect("activate", cb)
            menu.append(item)
        menu.show_all()
        self.ind.set_menu(menu)

    def refresh(self):
        threading.Thread(target=self._work, daemon=True).start()
        return True  # keep the GLib timer alive

    @staticmethod
    def _color(remaining):
        return "#e5484d" if remaining < 20 else "#f5a524" if remaining < 40 else "#30a46c"

    def _lines(self, rows):
        lines = ["<b>Claude Code</b>  <small>(local logs)</small>", "-"]
        for r in rows:
            sub = f"{r['used_text']} used"
            if r["resets_in"] != "-":
                sub += f"  ·  resets in {r['resets_in']}"
            if "remaining_pct" in r:
                rem = r["remaining_pct"]
                head = (f"<tt>{r['name']:<12}</tt> "
                        f"<span foreground='{self._color(rem)}'><tt>{bar(rem)}  {rem:.0f}% left</tt></span>")
            else:
                head = f"<tt>{r['name']:<12}</tt> <tt>{r['used_text']} used</tt>"
                sub = sub.replace(f"{r['used_text']} used  ·  ", "")
            lines += [head, f"<small>    {sub}</small>", "-"]
        if not any("remaining_pct" in r for r in rows):
            lines += ["<small>No limits set - see README (--calibrate)</small>"]
        return lines[:-1] if lines[-1] == "-" else lines

    def _work(self):
        try:
            rows = claude.fetch(load_config())
            lines, label = self._lines(rows), summary(rows)
        except claude.UsageError as e:
            lines, label = [f"Claude: {e}"], "Claude ⚠"
        GLib.idle_add(self._update, label, lines)

    def _update(self, label, lines):
        self.ind.set_label(label, "Claude\u20035h: 100% left\u2003\u2502\u20037d: 100% left")
        self.set_menu(lines)
        return False


def run():
    Monitor()
    Gtk.main()
