"""Claude Code usage, computed purely from local logs (~/.claude/projects/**/*.jsonl).

No network access and no credentials are used. Because Anthropic does not expose the
subscription's real remaining quota locally, "remaining" is relative to limits you set
in the config file (see README). Without limits, only used tokens are shown.
"""
import glob
import json
import os
import time
from datetime import datetime, timedelta, timezone

LOG_GLOB = os.path.expanduser("~/.claude/projects/**/*.jsonl")
BLOCK = timedelta(hours=5)
WEEK = timedelta(days=7)


class UsageError(Exception):
    pass


def _parse_ts(s):
    return datetime.fromisoformat(s.replace("Z", "+00:00"))


def _entries(since, count_cache_read):
    """Yield (timestamp, tokens) per unique API response newer than `since`."""
    best = {}  # (message id, request id) -> (ts, tokens); streamed duplicates keep the max
    cutoff = since.timestamp()
    for path in glob.glob(LOG_GLOB, recursive=True):
        try:
            if os.path.getmtime(path) < cutoff:
                continue
            with open(path, encoding="utf-8", errors="replace") as f:
                for line in f:
                    if '"usage"' not in line:
                        continue
                    try:
                        d = json.loads(line)
                        msg = d["message"]
                        u = msg["usage"]
                        ts = _parse_ts(d["timestamp"])
                    except (ValueError, KeyError, TypeError):
                        continue
                    if d.get("type") != "assistant" or ts < since:
                        continue
                    tokens = (u.get("input_tokens", 0) + u.get("output_tokens", 0)
                              + u.get("cache_creation_input_tokens", 0)
                              + (u.get("cache_read_input_tokens", 0) if count_cache_read else 0))
                    key = (msg.get("id"), d.get("requestId"))
                    if key not in best or tokens > best[key][1]:
                        best[key] = (ts, tokens)
        except OSError:
            continue
    return sorted(best.values())


def _fmt_delta(td):
    secs = int(td.total_seconds())
    if secs <= 0:
        return "now"
    h, m = divmod(secs // 60, 60)
    d, h = divmod(h, 24)
    return f"{d}d {h}h" if d else f"{h}h {m}m"


def _fmt_tokens(n):
    return f"{n/1e6:.1f}M" if n >= 1e6 else f"{n/1e3:.0f}k" if n >= 1e3 else str(n)


def _row(key, name, used, limit, resets_in):
    row = {"key": key, "name": name, "used_tokens": used, "limit": limit,
           "used_text": _fmt_tokens(used), "resets_in": resets_in}
    if limit:
        row["used_pct"] = min(100.0, used / limit * 100)
        row["remaining_pct"] = max(0.0, 100.0 - row["used_pct"])
    return row


def fetch(cfg=None, raw=False):
    cfg = cfg or {}
    now = datetime.now(timezone.utc)
    entries = _entries(now - WEEK, cfg.get("count_cache_read", False))

    # 5h session block: starts at the hour of the first message, lasts 5h; a message after
    # the block ends starts a new one (same idea as ccusage).
    block_start = block_end = None
    block_tokens = 0
    for ts, tokens in entries:
        if block_end is None or ts >= block_end:
            block_start = ts.replace(minute=0, second=0, microsecond=0)
            block_end = block_start + BLOCK
            block_tokens = 0
        block_tokens += tokens
    active = block_end is not None and now < block_end
    if not active:
        block_tokens, block_end = 0, None

    week_tokens = sum(t for _, t in entries)
    week_first = entries[0][0] if entries else None

    rows = [
        _row("five_hour", "5h session", block_tokens, cfg.get("limit_5h"),
             _fmt_delta(block_end - now) if block_end else "-"),
        _row("seven_day", "Last 7 days", week_tokens, cfg.get("limit_7d"),
             _fmt_delta(week_first + WEEK - now) if week_first else "-"),
    ]
    return rows
