"""Gemini provider - not implemented yet.

Gemini has no queryable "remaining quota" endpoint for the web app, and the right
approach depends on how it is used (CLI / API key / AI Studio). Implement
`fetch()` returning the same row format as providers/claude.py to enable it.
"""


def fetch(raw=False):
    raise NotImplementedError("Gemini provider is not implemented yet")
