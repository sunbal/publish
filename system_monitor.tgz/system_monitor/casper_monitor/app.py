import json
import os
import sys

from .providers import claude

CONFIG = os.path.expanduser("~/.config/casper_system_monitor/config.json")
DEFAULTS = {"interval_seconds": 120, "limit_5h": None, "limit_7d": None, "count_cache_read": False}


def load_config():
    try:
        with open(CONFIG) as f:
            return {**DEFAULTS, **json.load(f)}
    except (OSError, ValueError):
        return dict(DEFAULTS)


SHORT = {"five_hour": "5h", "seven_day": "7d"}


SEP = "\u2003\u2502\u2003"  # em space, box line, em space: the panel label can't be styled


def summary(rows):
    """Top-bar text: remaining % if a limit is configured, else used tokens."""
    parts = [f"{SHORT[r['key']]}: {r['remaining_pct']:.0f}% left" if "remaining_pct" in r
             else f"{SHORT[r['key']]}: {r['used_text']} used" for r in rows]
    return "Claude\u2003" + SEP.join(parts)


def bar(pct, width=10):
    filled = round(pct / 100 * width)
    return "▰" * filled + "▱" * (width - filled)


def describe(r):
    if "remaining_pct" in r:
        text = f"{r['name']}: {r['remaining_pct']:.0f}% left ({r['used_text']} used)"
    else:
        text = f"{r['name']}: {r['used_text']} tokens used (no limit set)"
    return text + (f"  - resets in {r['resets_in']}" if r["resets_in"] != "-" else "")


def calibrate(which, pct):
    """Set a limit so the current usage equals `pct`% (value read from Claude Code's /usage)."""
    key = {"5h": "five_hour", "7d": "seven_day"}.get(which)
    if key is None or not 0 < pct <= 100:
        sys.exit("usage: --calibrate <5h|7d> <percent 1-100 shown by /usage>")
    row = next(r for r in claude.fetch(load_config()) if r["key"] == key)
    if row["used_tokens"] <= 0:
        sys.exit(f"No {which} usage in local logs yet, cannot calibrate.")
    limit = round(row["used_tokens"] / (pct / 100))
    try:
        with open(CONFIG) as f:
            cfg = json.load(f)
    except (OSError, ValueError):
        cfg = {}
    cfg["limit_5h" if which == "5h" else "limit_7d"] = limit
    os.makedirs(os.path.dirname(CONFIG), exist_ok=True)
    with open(CONFIG, "w") as f:
        json.dump(cfg, f, indent=2)
    print(f"{which} limit set to {limit:,} tokens ({row['used_text']} used = {pct:g}%)")


def main():
    if "--calibrate" in sys.argv:
        i = sys.argv.index("--calibrate")
        try:
            calibrate(sys.argv[i + 1], float(sys.argv[i + 2]))
        except (IndexError, ValueError):
            sys.exit("usage: --calibrate <5h|7d> <percent 1-100 shown by /usage>")
        return
    if "--once" in sys.argv or "--dump" in sys.argv:
        rows = claude.fetch(load_config())
        if "--dump" in sys.argv:
            print(json.dumps(rows, indent=2))
        else:
            print(summary(rows))
            for r in rows:
                print("  " + describe(r))
        return
    from .tray import run  # GUI libraries are only needed for the tray mode
    run()
