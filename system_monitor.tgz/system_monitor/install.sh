#!/usr/bin/env bash
# Usage:
#   ./install.sh          install dependencies and register autostart
#   ./install.sh clean    stop the monitor and remove what install.sh set up
set -euo pipefail
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
AUTOSTART=~/.config/autostart/casper-system-monitor.desktop
CONFIG_DIR=~/.config/casper_system_monitor
PKGS=(gir1.2-ayatanaappindicator3-0.1 gnome-shell-extension-appindicator)

ask() { read -r -p "$1 [y/N] " a; [[ "$a" =~ ^[Yy]$ ]]; }

install() {
    sudo apt install -y "${PKGS[@]}"
    mkdir -p ~/.config/autostart
    cat > "$AUTOSTART" <<DESKTOP
[Desktop Entry]
Type=Application
Name=Casper System Monitor
Exec=python3 $DIR/casper_monitor.py
X-GNOME-Autostart-enabled=true
DESKTOP
    echo "Installed. Log out/in, or run: python3 $DIR/casper_monitor.py &"
}

clean() {
    pkill -f "$DIR/casper_monitor.py" 2>/dev/null && echo "Stopped running monitor" || true
    if [[ -e "$AUTOSTART" ]]; then rm "$AUTOSTART" && echo "Removed autostart entry"; fi
    if [[ -d "$CONFIG_DIR" ]] && ask "Delete config $CONFIG_DIR?"; then
        rm -r "$CONFIG_DIR" && echo "Removed config"
    fi
    # Other programs may use these packages, so ask before removing.
    if ask "Also apt-remove ${PKGS[*]}?"; then
        sudo apt remove -y "${PKGS[@]}"
    fi
    echo "Clean done. The source folder $DIR was left in place."
}

case "${1:-install}" in
    install) install ;;
    clean)   clean ;;
    *) echo "Usage: $0 [install|clean]" >&2; exit 1 ;;
esac
