const { Plugin, Notice, PluginSettingTab, Setting, normalizePath } = require("obsidian");

const DEFAULTS = { folderName: "resource" };
const IMG_EXT = { "image/png": "png", "image/jpeg": "jpg", "image/gif": "gif", "image/webp": "webp", "image/bmp": "bmp", "image/svg+xml": "svg" };

function pad(n) { return String(n).padStart(2, "0"); }
function timestamp() {
  const d = new Date();
  return `${d.getFullYear()}${pad(d.getMonth() + 1)}${pad(d.getDate())}${pad(d.getHours())}${pad(d.getMinutes())}${pad(d.getSeconds())}`;
}

module.exports = class LocalResourcePlugin extends Plugin {
  async onload() {
    console.log(`Local Resource Images v${this.manifest.version} loaded`);
    this.settings = Object.assign({}, DEFAULTS, await this.loadData());
    this.addSettingTab(new SettingTab(this.app, this));

    this.registerEvent(this.app.workspace.on("editor-paste", (evt, editor, info) => {
      if (evt.defaultPrevented || !evt.clipboardData) return;
      const files = this.imageFiles(evt.clipboardData);
      if (!files.length || !info.file) return;
      evt.preventDefault();
      this.handle(files, editor, info.file);
    }));

    this.registerEvent(this.app.workspace.on("editor-drop", (evt, editor, info) => {
      if (evt.defaultPrevented || !evt.dataTransfer) return;
      const files = this.imageFiles(evt.dataTransfer);
      if (!files.length || !info.file) return;
      evt.preventDefault();
      this.handle(files, editor, info.file);
    }));
  }

  // Linux screenshots often arrive only via DataTransfer.items, not .files
  imageFiles(dt) {
    let files = Array.from(dt.files || []);
    if (!files.length) {
      files = Array.from(dt.items || [])
        .filter((it) => it.kind === "file")
        .map((it) => it.getAsFile())
        .filter(Boolean);
    }
    return files.filter((f) => f.type in IMG_EXT);
  }

  async handle(files, editor, note) {
    const parent = note.parent && note.parent.path !== "/" ? note.parent.path : "";
    const dir = normalizePath(parent ? `${parent}/${this.settings.folderName}` : this.settings.folderName);
    try {
      if (!(await this.app.vault.adapter.exists(dir))) await this.app.vault.createFolder(dir);
      const links = [];
      for (const [i, f] of files.entries()) {
        const ext = IMG_EXT[f.type];
        // <note name>-<timestamp>; strip characters that break file names or links
        const noteName = note.basename.replace(/[\\/:*?"<>|#^\[\]]/g, "_");
        const base = `${noteName}-${timestamp()}${files.length > 1 ? "-" + (i + 1) : ""}`;
        let path = normalizePath(`${dir}/${base}.${ext}`);
        for (let n = 1; await this.app.vault.adapter.exists(path); n++) path = normalizePath(`${dir}/${base} ${n}.${ext}`);
        const created = await this.app.vault.createBinary(path, await f.arrayBuffer());
        links.push(this.app.fileManager.generateMarkdownLink(created, note.path));
      }
      editor.replaceSelection(links.map((l) => (l.startsWith("!") ? l : "!" + l)).join("\n"));
    } catch (e) {
      console.error(e);
      new Notice("Local Resource Images: failed to save image - " + e.message);
    }
  }
};

class SettingTab extends PluginSettingTab {
  constructor(app, plugin) { super(app, plugin); this.plugin = plugin; }
  display() {
    this.containerEl.empty();
    new Setting(this.containerEl)
      .setName("Resource folder name")
      .setDesc("Created next to each note; images are saved here.")
      .addText((t) => t.setValue(this.plugin.settings.folderName).onChange(async (v) => {
        this.plugin.settings.folderName = v.trim() || DEFAULTS.folderName;
        await this.plugin.saveData(this.plugin.settings);
      }));
  }
}
